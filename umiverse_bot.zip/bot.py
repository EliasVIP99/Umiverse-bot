from telegram.ext import ApplicationBuilder

print("Umiverse Bot placeholder.")
